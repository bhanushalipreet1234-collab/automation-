# config.py

GITHUB_TOKEN = "your_github_token_here"
REPO_NAME = "yourusername/your-repo"

OPENAI_API_KEY = "your_openai_api_key_here"

# Keywords to look for in issues/PRs
KEYWORDS = ["bug", "feature", "AI", "help"]
